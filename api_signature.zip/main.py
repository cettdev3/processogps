from email import charset
import json
from unicodedata import name
from caworker import Worker
import time
import requests
from matplotlib.font_manager import json_dump, json_load

    # curso,
    # tipoSolicitacao: 
    
    # transporte:  MotoristaHabilitadoCpf ou contratServLocalExecucao ou compraPassRg
    # diaria, adiantamento,

    # solProtocEmail,
    # solProtocNomeCompleto,
    # solProtocTelefone,
    # solProtocPrioridade,
    # solProtocDepartamento,
    # solProtocInstRefer,
    # solProtocProjeto,
    # solProtocJustificativaNec,
    # solProtocDataRealiz,
    # solProtocDataLocal,
    # solProtocTipoInsumo,

    # recebedorNome,
    # recebedorCpf,
    # recebedorTelefone,
    # recebedorLinkAnexos,
    # recebedorConfirmEnvio,

    # aluguelTranspJustificativa,

    # MotoristaHabilitadoNomeCompleto,
    # MotoristaHabilitadoCpf,
    # MotoristaHabilitadoCargo,
    # MotoristaHabilitadoNascimento,
    # MotoristaHabilitadoRg,
    # MotoristaHabilitadoOrgaoEm,
    # MotoristaHabilitadoEndereco,
    # MotoristaHabilitadoCep,
    # MotoristaHabilitadoEmail,
    # MotoristaHabilitadoTelefone,
    # MotoristaHabilitadoCronogViagem,
    # MotoristaHabilitadoInstRef,
    # MotoristaHabilitadoLinkCnh,
    # MotoristaHabilitadolocalHorVeiculo,
    # contratarMotoristaAdicional,
    # MotoristaHabilitadoDescVeiculo,

    # contratServInstituicaoRef,
    # contratServJustNecesside,
    # contratServLocalExecucao,

    # compraPassJustificativaNecess,
    # compraPassNomeCompleto,
    # compraPassNomeCargo,
    # compraPassNascimento,
    # compraPassRg,
    # compraPassOrgaoEmissor,
    # compraPassEndereco,
    # compraPassCep,
    # compraPassEmail,
    # compraPassTelefone,
    # compraPassBanco,
    # compraPassAgencia,
    # compraPassConta,
    # compraPassPix,
    # compraPassCronogSaidaData,
    # compraPassCronogSaidaHora,
    # compraPassCronogRetornoData,
    # compraPassCronogRetornoHora,
    # compraPassLinkRgCnh,
    # ConfirmacaoAluguelTransporte,

    # SolDiariasProfessorSelect,
    # solDiariasProfJustificativa,
    # solDiariasProfNomeCompleto,
    # solDiariasProfCpf,
    # solDiariasProfCargo,
    # solDiariasProfNascimento,
    # solDiariasProfRg,
    # solDiariasProfOrgaoEmissor,
    # solDiariasProfEndereco,
    # solDiariasProfCep,
    # solDiariasProfEmail,
    # solDiariasProfTelefone,
    # solDiariasProfBanco,
    # solDiariasProfAgencia,
    # solDiariasProfConta,
    # solDiariasProfPix,
    # solDiariasProfCronogramaViagem,
    # solDiariasProfInstReferencia,
    # confSolDiariasProf,
    
    # confSolDiariasAuxExt,
    
    # SolDiariasMotoristaessorSelect,
    # solDiariasMotoristaJustificativa,
    # solDiariasMotoristaNomeCompleto,
    # solDiariasMotoristaCpf,
    # solDiariasMotoristaCargo,
    # solDiariasMotoristaNascimento,
    # solDiariasMotoristaRg,
    # solDiariasMotoristaOrgaoEmissor,
    # solDiariasMotoristaEndereco,
    # solDiariasMotoristaCep,
    # solDiariasMotoristaEmail,
    # solDiariasMotoristaTelefone,
    # solDiariasMotoristaBanco,
    # solDiariasMotoristaAgencia,
    # solDiariasMotoristaConta,
    # solDiariasMotoristaPix,
    # solDiariasMotoristaCronogramaViagem,
    # solDiariasMotoristaInstReferencia,
    # confSolDiariasMotorista,

    # adiantEqExecJustificativaComb,
    # adiantEqExecCronogramaRealizComb,
    # adiantEqExecNomeCompletoComb,
    # adiantEqExecCpfComb,
    # adiantEqExecRgComb,
    # adiantEqExecCargoComb,
    # adiantEqExecNascimentoComb,
    # adiantEqExecOrgaoEmissorComb,
    # adiantEqExecEnderecoComb,
    # adiantEqExecCepComb,
    # adiantEqExecEmailComb,
    # adiantEqExecTelefoneComb,
    # adiantEqExecBancoComb,
    # adiantEqExecAgenciaComb,
    # adiantEqExecContaComb,
    # adiantEqExecPixComb,
    # adiantEqExecDataLimiteComb,
    # adiantEqExecInstReferenciaComb,
    # confAdiantEqExecComb
    
    # adiantEqExecJustificativaIns,
    # adiantEqExecCronogramaRealizIns,
    # adiantEqExecNomeCompletoIns,
    # adiantEqExecCpfIns,
    # adiantEqExecRgIns,
    # adiantEqExecCargoIns,
    # adiantEqExecNascimentoIns,
    # adiantEqExecOrgaoEmissorIns,
    # adiantEqExecEnderecoIns,
    # adiantEqExecCepIns,
    # adiantEqExecEmailIns,
    # adiantEqExecTelefoneIns,
    # adiantEqExecBancoIns,
    # adiantEqExecAgenciaIns,
    # adiantEqExecContaIns,
    # adiantEqExecPixIns,
    # adiantEqExecDataLimiteIns,
    # adiantEqExecInstReferenciaIns,
    # confAdiantEqExecIns

def saveOnJumla(nome):
    # subject: tipo de requisição: 

    obj = {
        "authentication": {
            "api_key": "4157603089f949dcb76aea92088823e0",
            "api_secret": "20d4a4959a421a4615d8f7aca545a0457800354268559e3ed3fc724ef1dc8c29"
        },
        "data": {
            "email": dadosSolicitante["email"],
            "priorityid": "3",
            "name": nome,
            "phone": dadosSolicitante["phone"],
            "departmentid": "27",
            "projeto": dadosSolicitante["projeto"],
            "instituicao": dadosSolicitante["instituicao"],
            "subject": dadosSolicitante["subject"],
            "message": dadosSolicitante["message"],
            "etapa": "Cadastrado",
            "limite_execucao": "data do cronograma: novo campo",
        }				   
    }
    json_dump = json.dumps(obj)
    URL = "https://protocolo2.cett.dev.br/plugins/jssupportticket/js_support_ticket_API/js_support_ticket_API.php"
    return requests.post(
            URL,
            json_dump
        )

worker=Worker()

if __name__ == '__main__':
    print('Worker started')
    while True:
        
        tasks = worker.fetch_tasks()

        for task in tasks:
            try:
                solProtocEmail = task.variables['solProtocEmail'].value
                solProtocNomeCompleto = task.variables['solProtocNomeCompleto'].value
                solProtocTelefone = task.variables['solProtocTelefone'].value
                solProtocPrioridade = task.variables['solProtocPrioridade'].value
                solProtocDepartamento = task.variables['solProtocDepartamento'].value
                solProtocInstRefer = task.variables['solProtocInstRefer'].value
                solProtocProjeto = task.variables['solProtocProjeto'].value
                solProtocJustificativaNec = task.variables['solProtocJustificativaNec'].value
                solProtocDataRealiz = task.variables['solProtocDataRealiz'].value
                solProtocDataLocal = task.variables['solProtocDataLocal'].value
                solProtocTipoInsumo = task.variables['solProtocTipoInsumo'].value
                
                
                dadosSolicitante = {
                    "email": solProtocEmail,
                    "name": solProtocNomeCompleto,
                    "phone": solProtocTelefone,
                    "instituicao": solProtocInstRefer,
                    "projeto": solProtocProjeto,
                    "subject": "requisição de transporte"+"-confeitaria"+"-pirinopolis-"+solProtocNomeCompleto,
                    "message": "textão"
                }

                response = saveOnJumla(dadosSolicitante)

                response = json.loads(response.content)
                print("depois do upload", response["ticketid"])
                worker.complete_task(task_id=task.id_,
                variables={"boaIluminacao": {"value": "teste idJumla", "name": "ticketId"},})
            except:
                pass

            print('Inserção realizada com sucesso!')
        time.sleep(5)



from __future__ import unicode_literals
import json
import os
from django.core import serializers
from django.db import models
import requests

URL = "https://assinador.registrodeimoveis.org.br/api/"
API_KEY = "FUNDACAO RADIO E TELEVISAO EDUCATIVA E CULTURAL|001be6603165594b87b5c083c2e7eee139d3b775413954bbaa13ed264c252b02"
    

class Document(models.Model):
    name = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def filename(self):
        return os.path.basename(self.document.name)

class DocumentCreated(models.Model):
    id = models.CharField(max_length=255,blank=True,primary_key=True)
    location = models.CharField(max_length=2000,blank=True)
    displayName = models.CharField(max_length=2000,blank=True)
    contentType = models.CharField(max_length=2000,blank=True)

    class Meta:
        managed = False

class User(models.Model):
    name = models.CharField(max_length=2000,blank=True)
    identifier = models.CharField(max_length=2000,blank=True)
    email = models.CharField(max_length=2000,blank=True)

    def getJsonRepresentation(self):
        return {
            "name": self.name, 
            "identifier": self.identifier, 
            "email": self.email, 
        }

    class Meta:
        managed = False

class FlowAction(models.Model):
    type = models.CharField(max_length=2000,blank=True)
    step = models.IntegerField(blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    allowElectronicSignature =  models.BooleanField(blank=True)
    
    def getJsonRepresentation(self):
        return {
            "type": self.type, 
            "step": self.step, 
            "allowElectronicSignature": self.allowElectronicSignature, 
            "user": self.user.getJsonRepresentation(), 
        }

    class Meta:
        managed = False

class SignApiService(models.Model):
    
    def uploadDocument(self, document, file):
        return requests.post(
            URL+"uploads",
            {"name" : document.name},
            headers={
                "X-Api-Key": API_KEY
            },
            files=file
        )
    
    def createDocument(self, documentCreated: DocumentCreated, flowEventsArray):
        payload =  {
            "files": [
                {
                    "displayName": documentCreated.displayName,
                    "id": documentCreated.id,
                    "name": documentCreated.displayName,
                    "contentType": "application/pdf"
                }
            ],
            "flowActions": [
                flowEventsArray
            ]
        }

        print(payload)
        return requests.post(
            URL+"documents",
            json.dumps(payload),
            headers={
                "X-Api-Key": API_KEY,
                "Content-Type": "application/json"
            }
        )

    class Meta:
        managed = False
    
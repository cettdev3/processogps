import json
from xml.dom.minidom import Identified
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
from core.forms import DocumentForm
from core.models import Document, DocumentCreated, FlowAction, SignApiService, User
from django.views.decorators.csrf import csrf_exempt

def home(request):
    documents = Document.objects.all()
    return render(request, 'core/home.html', { 'documents': documents })


def simple_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)

        return render(request, 'core/simple_upload.html', {
            'uploaded_file_url': uploaded_file_url
        })
    return render(request, 'core/simple_upload.html')


def model_form_upload(request):
    if request.method == 'POST':
        print("antes do upload")
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            document = form.save(commit=False)
            api = SignApiService()
            response = api.uploadDocument(
                document, 
                request.FILES
            )

            
            response = json.loads(response.content)
            print("depois do upload", response)
            
            documentCreated = DocumentCreated(
                response['id'], 
                response['location'], 
                response['name'], 
                response['contentType']
            )

            user = User(
                name="kaike batista da silva",
                identifier="75410907191",
                email="desenvolvedor2@cett.org.br",
            )

            flowEvent = FlowAction(
                type="Signer",
                step=1,
                user=user,
                allowElectronicSignature=True
            ).getJsonRepresentation()
            response = api.createDocument(
                documentCreated, 
                flowEvent
            )
            print(flowEvent, response.content)
            return redirect('home')
    else:
        form = DocumentForm()
    return render(request, 'core/model_form_upload.html', {
        'form': form
    })

@csrf_exempt
def webhookDocumentComplete(request):
    
    print("printando request, Documento Concluido")
    print(request.body)
    return  HttpResponse('')
